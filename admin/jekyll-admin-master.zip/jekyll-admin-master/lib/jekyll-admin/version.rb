# frozen_string_literal: true

module JekyllAdmin
  VERSION = "0.10.2"
end
