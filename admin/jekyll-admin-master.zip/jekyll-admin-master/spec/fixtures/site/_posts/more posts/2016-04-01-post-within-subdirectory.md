---
title: Post Within Subdirectory
foo: bar
tag: foo
---

# Test Post within `_posts/more posts`
