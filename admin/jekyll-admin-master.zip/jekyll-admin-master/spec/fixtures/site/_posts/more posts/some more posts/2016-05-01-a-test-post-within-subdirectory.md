---
title: A Test Post Within Subdirectory
foo: bar
---

# Test Post within `_posts/more posts/some more posts`
