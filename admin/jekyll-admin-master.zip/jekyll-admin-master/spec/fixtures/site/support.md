---
redirect_from: '/webmaster.html'
---

Page to test redirection artefacts
