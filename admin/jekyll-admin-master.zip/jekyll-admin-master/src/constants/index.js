export const ADMIN_PREFIX = '/admin';
